
# RAG Pipeline for Amazon Reviews: Embedding + Retrieval + Summarization

import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
from transformers import pipeline

# Load preprocessed data (filtered + cleaned)
df = pd.read_csv('preprocessed_amazon_reviews.csv')

# Sample 10k for RAG
df_rag = df[['product_title', 'cleaned_review_body', 'star_rating']].dropna().sample(n=10000, random_state=42)
corpus = (df_rag['product_title'] + " - " + df_rag['cleaned_review_body']).tolist()

# Generate embeddings
model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(corpus, show_progress_bar=True)

# Build FAISS index
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(embeddings))
print(f"Indexed {len(embeddings)} product review entries.")

# Create metadata mapping
index_metadata = df_rag.reset_index(drop=True)

# Summarization pipeline (HuggingFace)
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

# Query function
def retrieve_and_summarize(query, k=5):
    query_embedding = model.encode([query])
    D, I = index.search(np.array(query_embedding), k)
    results = index_metadata.iloc[I[0]]
    
    combined_reviews = " ".join(results['cleaned_review_body'].tolist())
    summary = summarizer(combined_reviews, max_length=130, min_length=30, do_sample=False)[0]['summary_text']
    
    print(f"🔎 Query: {query}\n")
    print(f"📝 Summary of top {k} reviews:")
    print(summary)
    return results[['product_title', 'star_rating', 'cleaned_review_body']]
