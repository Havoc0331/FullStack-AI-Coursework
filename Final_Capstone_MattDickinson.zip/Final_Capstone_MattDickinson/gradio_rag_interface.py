
# Gradio Interface for RAG-Based Review Summarizer

import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
from transformers import pipeline
import gradio as gr

# Load and sample data
df = pd.read_csv('preprocessed_amazon_reviews.csv')
df_rag = df[['product_title', 'cleaned_review_body', 'star_rating']].dropna().sample(n=10000, random_state=42)
corpus = (df_rag['product_title'] + " - " + df_rag['cleaned_review_body']).tolist()

# Generate embeddings
embedder = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = embedder.encode(corpus, show_progress_bar=True)

# Build FAISS index
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(embeddings))
index_metadata = df_rag.reset_index(drop=True)

# Summarizer pipeline
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

# Retrieval + summarization logic
def summarize_reviews(query, top_k=5):
    query_vector = embedder.encode([query])
    _, indices = index.search(np.array(query_vector), top_k)
    results = index_metadata.iloc[indices[0]]
    combined_text = " ".join(results['cleaned_review_body'].tolist())
    summary = summarizer(combined_text, max_length=130, min_length=30, do_sample=False)[0]['summary_text']
    
    # Show top matching titles and ratings
    preview = "\n".join([f"{row['star_rating']}⭐ - {row['product_title']}" for _, row in results.iterrows()])
    return summary, preview

# Gradio Interface
iface = gr.Interface(
    fn=summarize_reviews,
    inputs=[
        gr.Textbox(lines=2, label="Enter product or topic"),
        gr.Slider(minimum=1, maximum=10, step=1, value=5, label="Top K Results")
    ],
    outputs=[
        gr.Textbox(label="Summary of Reviews"),
        gr.Textbox(label="Top Matching Reviews")
    ],
    title="Amazon Reviews Summarizer (RAG)",
    description="Enter a product or topic to summarize relevant customer reviews using retrieval-augmented generation."
)

if __name__ == "__main__":
    iface.launch()
