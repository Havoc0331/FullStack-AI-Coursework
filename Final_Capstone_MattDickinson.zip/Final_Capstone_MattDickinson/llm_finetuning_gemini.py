from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer

# Load dataset (replace with your CSV of cleaned product reviews)
dataset = load_dataset('csv', data_files='preprocessed_amazon_reviews.csv')

# Define model and tokenizer (e.g., Mistral or Falcon)
model_name = "tiiuae/falcon-rw-1b"  # or "mistralai/Mistral-7B-Instruct-v0.1"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# Preprocess reviews for text generation or summarization fine-tuning
def preprocess(example):
    example["text"] = "Summarize: " + example["cleaned_review_body"]
    return example

tokenized = dataset.map(preprocess).map(lambda e: tokenizer(e["text"], truncation=True, padding="max_length"), batched=True)

# Training setup (adjust for your compute)
args = TrainingArguments(
    output_dir="./fine_tuned_model",
    per_device_train_batch_size=4,
    num_train_epochs=1,
    logging_dir="./logs",
    logging_steps=10,
    save_steps=100,
    evaluation_strategy="no"
)

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=tokenized["train"]
)


# ---------------- Google Gemini API Integration ---------------------

import requests

def query_gemini(prompt, api_key):
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + api_key
    headers = {"Content-Type": "application/json"}
    data = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    return response.json()['candidates'][0]['content']['parts'][0]['text']

