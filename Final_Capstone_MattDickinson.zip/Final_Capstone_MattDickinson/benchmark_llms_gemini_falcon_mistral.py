
# Benchmarking Gemini vs Falcon vs Mistral on Review Summarization

import requests
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
import torch

# ---------------------------- GEMINI SETUP ----------------------------
def query_gemini(prompt, api_key):
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + api_key
    headers = {"Content-Type": "application/json"}
    data = {
        "contents": [
            {
                "parts": [{"text": prompt}]
            }
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    return response.json()['candidates'][0]['content']['parts'][0]['text']


# ---------------------------- Falcon Setup ----------------------------
def load_falcon():
    model_name = "tiiuae/falcon-rw-1b"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32)
    return pipeline("text-generation", model=model, tokenizer=tokenizer, device=0 if torch.cuda.is_available() else -1)


# ---------------------------- Mistral Setup ----------------------------
def load_mistral():
    model_name = "mistralai/Mistral-7B-Instruct-v0.1"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32)
    return pipeline("text-generation", model=model, tokenizer=tokenizer, device=0 if torch.cuda.is_available() else -1)


# ---------------------------- Benchmark Routine ----------------------------
def benchmark_models(prompt, gemini_api_key):
    print("\nPrompt: ", prompt)
    print("\n----- GEMINI OUTPUT -----")
    try:
        gemini_result = query_gemini(prompt, gemini_api_key)
        print(gemini_result)
    except Exception as e:
        print("Gemini error:", e)

    print("\n----- FALCON OUTPUT -----")
    try:
        falcon_pipe = load_falcon()
        falcon_result = falcon_pipe(prompt, max_new_tokens=100)[0]['generated_text']
        print(falcon_result)
    except Exception as e:
        print("Falcon error:", e)

    print("\n----- MISTRAL OUTPUT -----")
    try:
        mistral_pipe = load_mistral()
        mistral_result = mistral_pipe(prompt, max_new_tokens=100)[0]['generated_text']
        print(mistral_result)
    except Exception as e:
        print("Mistral error:", e)


# ---------------------------- Run Example ----------------------------
if __name__ == "__main__":
    gemini_api_key = "your_gemini_api_key_here"

    sample_prompt = """Summarize the following product reviews:

    1. I love these shoes! Super comfy and stylish.

    2. Terrible quality. Fell apart in a week.

    3. Decent for the price but runs a bit small.

    4. Excellent purchase! I wear them daily.

    5. Not worth it. Very uncomfortable.
"""

    benchmark_models(sample_prompt, gemini_api_key)
