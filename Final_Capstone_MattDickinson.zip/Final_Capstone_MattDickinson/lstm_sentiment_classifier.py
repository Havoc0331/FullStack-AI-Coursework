
# LSTM-Based Sentiment Classifier for Amazon Reviews
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional

# Load preprocessed data (replace with actual path if needed)
df = pd.read_csv('preprocessed_amazon_reviews.csv')

# Map star_rating to sentiment
def map_sentiment(star):
    if star <= 2:
        return 'negative'
    elif star == 3:
        return 'neutral'
    else:
        return 'positive'

df['sentiment'] = df['star_rating'].apply(map_sentiment)
texts = df['cleaned_review_body'].tolist()
labels = df['sentiment'].tolist()

# Encode labels
le = LabelEncoder()
y = le.fit_transform(labels)
y_cat = to_categorical(y)

# Tokenize text
tokenizer = Tokenizer(num_words=10000, oov_token="<OOV>")
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
padded = pad_sequences(sequences, maxlen=200, padding='post')

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(padded, y_cat, test_size=0.2, random_state=42)

# Build LSTM model
model = Sequential([
    Embedding(input_dim=10000, output_dim=64, input_length=200),
    Bidirectional(LSTM(64)),
    Dropout(0.3),
    Dense(32, activation='relu'),
    Dense(3, activation='softmax')
])

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

# Train the model
history = model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=5, batch_size=128)

# Evaluate
loss, accuracy = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {accuracy:.4f}, Test Loss: {loss:.4f}")

# Save the model
model.save("lstm_sentiment_model.h5")
